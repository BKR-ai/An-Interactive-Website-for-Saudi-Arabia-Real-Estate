<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	if(isset($_GET['addCity']))	
		include_once	"includes/add_city.php";
	elseif(isset($_GET['editCity']))	
		include_once	"includes/edit_city.php";
	elseif(isset($_GET['deleteCity']))	
		include_once	"includes/delete_city.php";
	else
		include_once	"includes/cities.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
