<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";



	if(isset($_GET['owner']))	
		include_once	"includes/login_owner.php";
	elseif(isset($_GET['client']))	
		include_once	"includes/login_client.php";
	else
		include_once	"includes/login.php";

include_once	"includes/footer.php";

?>
