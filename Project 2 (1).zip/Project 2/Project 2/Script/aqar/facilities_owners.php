<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	if(isset($_GET['addOwner']))	
		include_once	"includes/add_facility_owner.php";
	elseif(isset($_GET['editOwner']))	
		include_once	"includes/edit_facility_owner.php";
	elseif(isset($_GET['editPassword']))	
		include_once	"includes/password_facility_owner.php";
	elseif(isset($_GET['deleteOwner']))	
		include_once	"includes/delete_facility_owner.php";
	else
		include_once	"includes/facilities_owners.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
