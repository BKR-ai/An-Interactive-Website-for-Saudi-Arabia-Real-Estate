        // JavaScript for image slider (optional, you can use a library like Swiper or Slick for more features)
        const imageSliders = document.querySelectorAll('.image-slider');
        imageSliders.forEach(slider => {
            let currentImage = 0;

            function showImage(index) {
                const images = slider.querySelectorAll('img');
                images.forEach((img, i) => {
                    img.style.display = i === index ? 'block' : 'none';
                });
            }

            function nextImage() {
                currentImage = (currentImage + 1) % images.length;
                showImage(currentImage);
            }

            function prevImage() {
                currentImage = (currentImage - 1 + images.length) % images.length;
                showImage(currentImage);
            }

            const images = slider.querySelectorAll('img');
            if (images.length > 1) {
                setInterval(nextImage, 3000); // Change image every 5 seconds (adjust as needed)
            }

            // Add event listeners for navigation buttons
            const prevButton = slider.querySelector('.slider-nav button:first-child');
            const nextButton = slider.querySelector('.slider-nav button:last-child');
            prevButton.addEventListener('click', prevImage);
            nextButton.addEventListener('click', nextImage);
        });

        function submitForm() {
            // Dummy function for demonstration purposes
            // In a real scenario, you'd likely want to use AJAX to submit the form data to a server
            // For simplicity, this example just shows/hides success or error messages

            const successMessage = document.getElementById('success-message');
            const errorMessage = document.getElementById('error-message');

            // Simulate a successful form submission
            successMessage.textContent = 'Message sent successfully!';
            successMessage.style.display = 'block';

            // Simulate an error in form submission
            // Uncomment the following lines to test the error message
            /*
            errorMessage.textContent = 'Error sending message. Please try again.';
            errorMessage.style.display = 'block';
            */

            // Clear the form fields after submission (optional)
            document.getElementById('name').value = '';
            document.getElementById('email').value = '';
            document.getElementById('message').value = '';

            // Optional: Hide messages after a few seconds
            setTimeout(() => {
                successMessage.style.display = 'none';
                errorMessage.style.display = 'none';
            }, 5000);
        }
        
        
        
        
        
        
        
        
        
        function submitBidForm() {
            const successMessage = document.getElementById('bid-success-message');
            const errorMessage = document.getElementById('bid-error-message');

            // Simulate a successful form submission
            successMessage.textContent = 'Bid submitted successfully!';
            successMessage.style.display = 'block';

            // Simulate an error in form submission
            // Uncomment the following lines to test the error message
            /*
            errorMessage.textContent = 'Error submitting bid. Please try again.';
            errorMessage.style.display = 'block';
            */

            // Clear the form fields after submission (optional)

            document.getElementById('bidAmount').value = '';
            document.getElementById('bidMessage').value = '';

            // Optional: Hide messages after a few seconds
            setTimeout(() => {
                successMessage.style.display = 'none';
                errorMessage.style.display = 'none';
            }, 5000);
        }
