<form action ="" Method="POST">
        <h2>طلب حجز موعد لمعاينة العقار</h2>
       
        <?php
        

$date = new DateTime(); // This initializes a DateTime object to the current date and time.
$date->modify('+1 day'); // This adds one day to the date.
$targetday =  $date->format('Y-m-d');


        if( isset($_POST['Go']) ){

           // echo "<pre>"; print_r($_POST); echo "</pre>";
			$adID       = (int)$_GET['appointment'];
			$ownerID    = show_data_founded('ads','adID',$adID,'ownerID');
			$clientID   = (int)$_SESSION['userid'];
			$day        = date('Y-m-d', strtotime($_POST['date']));
			$time       = $_POST['time'];
            $appointmentDate   = $day . ' ' . $time . ':00'; 

           $command = "
           INSERT INTO `appointments` (`appointmentID`, `adID`, `ownerID`, `clientID`, `appointmentDate`, `status`, `insertDate`) 
           VALUES (NULL, '$adID', '$ownerID', '$clientID', '$appointmentDate', 'new', current_timestamp()) 
        ";
        $result		=	$connect->query($command);
			
			echo ' <div class="message-show success-messages"  >تم إرسال طلب المعاينة إلى البائع وجاري إرجاعك إلى الإعلان</div>';
			header ("refresh:3; url=ads.php?show=$adID");
			die();
		}elseif( isset($_POST['Go']) ){
						echo ' <div class="message-show error-message"  >الرجاء التحقق من بيانات دخولك</div>';

		}
        
        ?>

        <label >إختر تاريخ المعاينة</label>
        <input type="date" name="date"  min=<?php echo $targetday;?>  required>
            
    <label for="time">إختر وقت المعاينة</label>
    <input type="time" id="time" name="time" required>

        <input type="submit" name="Go" value="أكد الموعد" >
       
        
    </form>
