

    <form action ="" Method="POST">
        <h2>حذف صورة من الإعلان</h2>
       
        <?php
        
        $image 		=	$_GET['delete_image'];
        $adID 		=	(int)$_GET['ads'];
        unlink($folder_uploads.$image);

        $command 	= 	"
        UPDATE ads
SET images = JSON_REMOVE(images, JSON_UNQUOTE(JSON_SEARCH(images, 'one', '$image')))
WHERE JSON_CONTAINS(images, '\"$image\"')
  AND adID = '$adID'
        ";
       
		$result		=	$connect->query($command);
		
			echo ' <div class="message-show success-messages"  >تمت عملية الحذف بنجاح وجاري تحويلك إلى صفحة تعديل الإعلان</div>';
			header ("refresh:3; url=?edit=$adID");
		
		
        ?>
      
    </form>
