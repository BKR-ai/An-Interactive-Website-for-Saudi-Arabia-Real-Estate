
<?php
$adsID = $_GET['edit'];
$command 	= " 
select ads.*,categories.title as catTile, cities.title as cityTitle from ads 
INNER JOIN categories 
INNER JOIN cities
where ownerID='".$_SESSION['userid']."'
and cities.cityID=ads.cityID
AND categories.catID=ads.catID
and ads.adID='".$adsID."'

order by adID DESC
";
$result		=	$connect->query($command);
$ads        = mysqli_fetch_assoc($result);

$images  = json_decode($ads['images'],JSON_UNESCAPED_UNICODE);
		$listImage = "<ul>";
		foreach ($images AS $img){
			$listImage .= "<li><a href='".$folder_uploads.$img."' target='_blank'>".$img."</a>  <a href='?delete_image=$img&ads=$adsID' ><img src='images/delete.png' ></a></li>";
		}
		$listImage .= "</ul>";


?>
    <form action ="" Method="POST" enctype="multipart/form-data" >
        <h2>تعديل إعلان</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 

		  ){
			
			$title				=	$_POST['title'];
			$description		=	addslashes($_POST['description']);
			$catID				=	(int)$_POST['catID'];
			$cityID				=	(int)$_POST['cityID'];
			$type				=	$_POST['type'];
			$closeDate			=	date('Y-m-d', strtotime($_POST['closeDate']));
			$image_array		=	array();
			$ownerID			=	(int)$_SESSION['userid'];
			
// Count # of uploaded files in array
$total = count($_FILES['images']['name']);

// Loop through each file
for( $i=0 ; $i < $total ; $i++ ) {

  //Get the temp file path
  $tmpFilePath = $_FILES['images']['tmp_name'][$i];
  $EXTENSION 	= strtolower(pathinfo($_FILES['images']['name'][$i],PATHINFO_EXTENSION));
  $newImageName	=	rand(22,9999).time().".".$EXTENSION;
  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = $folder_uploads.$newImageName;

    //Upload the file into the temp dir
    if(move_uploaded_file($tmpFilePath, $newFilePath)) {

      //array_push($image_array,$newImageName);

      $command 	= "
      UPDATE ads
SET images = JSON_ARRAY_APPEND(COALESCE(images, '[]'), '$', '".$newImageName."')
WHERE adID = '$adsID';

      ";
      $update		=	$connect->query($command);

    }
  }
}

$imagesJson	=	json_encode($image_array,true);

			$command 	= "
            update ads set catID='$catID', cityID='$cityID', title='$title', description='$description'
            ,type = '$type',closeDate ='$closeDate' 
            where adID= '$adsID'
			";
			$update		=	$connect->query($command);

            $deleteKeys		=	$connect->query("delete from adsdetails where adID='$adsID' ");
			
            foreach ($_POST['keys'] AS $index=>$value){
				$keyID = (int)$value;
				if(!empty($keyID) and $keyID>0){
					$command = "INSERT INTO `adsdetails` (`adKeyID`, `adID`, `keyID`) 
					VALUES (NULL, '$adsID', '$keyID' ) ";
					$insert = $connect->query($command);
				}
			}

			echo ' <div class="message-show success-messages"  >تمت تحديث إعلانك بنجاح وجاري تحويلك إلى قائمة إعلاناتك</div>';
			header ("refresh:3; url=?");
			die();
			

		}
        
        ?>
        <label >عنوان الإعلان</label>
        <input type="text" name="title" <?php if(isset($_POST['title'])) echo  ' value="'.$_POST['title'].'" '; else  echo  ' value="'.$ads['title'].'" ';  ?> required>
        <label>الوصف</label>
        <textarea name="description" required><?php if(isset($_POST['description'])) $_POST['description'];else echo $ads['description']; ?></textarea>
        <label >القسم</label>
        <select name ="catID" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			// <option value=""></option>
			$command 	= " select * from categories  order by catID  DESC";
			$result		=	$connect->query($command);
			while ( $category = mysqli_fetch_assoc($result)){
                
                if($category["catID"]==$ads['catID'])
				echo '<option value="'.$category['catID'].'" selected>'.$category['title'].'</option>';
				else
                echo '<option value="'.$category['catID'].'">'.$category['title'].'</option>';
			}
			?>
        </select>
        <label >المدينة</label>
        <select name ="cityID" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			$command 	= " select * from cities  order by cityID  DESC";
			$result		=	$connect->query($command);
			while ( $city = mysqli_fetch_assoc($result)){

                if($city["cityID"]==$ads["cityID"])
				echo '<option value="'.$city['cityID'].'" selected >'.$city['title'].'</option>';
				else
                echo '<option value="'.$city['cityID'].'">'.$city['title'].'</option>';
			}
			?>
        </select>
                
        <label >نوع الإعلان</label>
        <select name ="type" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			
			
			foreach($ads_types AS $type=>$title){
                
                if($type==$ads['type'])
				echo '<option value="'.$type.'" selected>'.$title.'</option>';
				else
                echo '<option value="'.$type.'">'.$title.'</option>';
			}
			?>
        </select>
		
		<label >تاريخ الإغلاق</label>
        <input type="date" name="closeDate" min="<?php echo date('Y-m-d');?>" <?php if(isset($_POST['closeDate'])) echo  ' value="'.$_POST['closeDate'].'" ';else echo ' value="'.$ads['closeDate'].'" '; ?> required>
        
        <label >الصور</label>
        <label ><?php echo $listImage;?></label>
        <input type="file" name="images[]" accept="image/*" multiple >
        
        <label>منتفعات العقار</label>

		
<?php
$command 	= "SELECT AD.*, DK.title FROM `adsdetails` as AD 
JOIN detailskeys as DK ON DK.keyID=AD.keyID
WHERE AD.adID='".$ads['adID']."' ";
$result		=	$connect->query($command);
while ( $key = mysqli_fetch_assoc($result)){
echo '<label class="checkbox-container">
      '.$key['title'].'
      <input type="checkbox" name="keys[]" value="'.$key['keyID'].'"  checked >
      <span class="checkmark"></span>
    </label>';

} 
$command 	= "
SELECT * from detailskeys where keyID not in (
    SELECT DK.keyID FROM `detailskeys` as DK 
    JOIN adsdetails as AD ON DK.keyID=AD.keyID
    WHERE AD.adID='".$ads['adID']."' 
    );
     ";
$result		=	$connect->query($command);
while ( $key = mysqli_fetch_assoc($result)){
echo '<label class="checkbox-container">
      '.$key['title'].'
      <input type="checkbox" name="keys[]" value="'.$key['keyID'].'"   >
      <span class="checkmark"></span>
    </label>';

} 

?>    


        <input type="submit" name="Go" value="عدل" >
       
        
    </form>
