<form action="" Method="POST">
    <h2>حذف اعلان عقاري</h2>
   
    <?php
    
    $id = (int)$_GET['remove'];

    // First, delete entries from all child tables that reference adID in the ads table.
    $resultAppointments = $connect->query("DELETE FROM appointments WHERE appointments.adID = '$id'");
    $resultBuyerOffers = $connect->query("DELETE FROM buyeroffers WHERE buyeroffers.adID = '$id' ");
    $resultBrokerage = $connect->query("DELETE FROM brokerage_value WHERE brokerage_value.adID = '$id'");
    $resultDetails = $connect->query("DELETE FROM adsdetails WHERE adsdetails.adID = '$id'");

    // After all references are removed, you can safely delete the entry from the ads table.
    $result = $connect->query("DELETE FROM ads WHERE adID = '$id' LIMIT 1");
    
    if ($result) {
        echo '<div class="message-show success-messages">تمت عملية الحذف بنجاح وجاري تحويلك إلى القائمة</div>';
        header("refresh:3; url=?");
    } else {
        echo '<div class="message-show error-messages">حدث خطأ أثناء الحذف</div>';
    }
    
    ?>
  
</form>
