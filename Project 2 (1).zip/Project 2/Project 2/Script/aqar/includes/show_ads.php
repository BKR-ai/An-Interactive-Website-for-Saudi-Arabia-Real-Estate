<?php
$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";


$adsID = (int)$_GET['show'];

if(isset($_GET['offer'])){
    $offer      = (int)$_GET['offer'];
    $update		=	$connect->query("UPDATE buyeroffers set status='approved' WHERE offerID='$offer' ");
    $update		=	$connect->query("UPDATE ads set status='accept' WHERE adID='$adsID' ");
}
$command 	= "
select ads.*,categories.title as catTile, cities.title as cityTitle, facilities_owners.*  from ads 
INNER JOIN categories  on categories.catID=ads.catID
INNER JOIN cities on cities.cityID=ads.cityID
INNER JOIN facilities_owners on facilities_owners.ownerID=ads.ownerID
where 
ads.adID='$adsID'
and cities.cityID=ads.cityID
AND categories.catID=ads.catID
order by adID DESC
limit 1
;
        ";
		$result		=	$connect->query($command);
		$row = mysqli_fetch_assoc($result);
        
		$images  = json_decode($row['images'],JSON_UNESCAPED_UNICODE);
		
?>



<section>  <!--  الـsection  يستخدم في تقسيم الصفحة الواحدة إلى عدة أقسام -->
        <div class="property-card">   <!-- بداية تصميم قسم عرض بيانات المنئشة -->
        <h2><?php echo $row['title'];?></h2> 
            <div class="image-slider">   <!-- بادية الصور المتحركة لصور المنشئة -->
            <div class="image-label"><?php echo show_type_ads($row['type']);?></div>
            <?php
                  foreach ($images as $image) {
                    echo '<img src="'.$folder_uploads.$image.'" >';
                }
                ?>
                
                <div class="slider-nav"> <!-- بداية تاق الصور للتنقل بينها -->
                    <button onclick="prevImage()">السابق</button>  <!-- ايقونة السابق بالجافا سكريبت -->
                    <button onclick="nextImage()">التالي</button>
                </div>
            </div>
            <h3 style="text-align:center;">أعلى عرض: <?php echo max_offer($row['adID']);?></h3>
            <?php 
                if(checker_client()==TRUE)
                    echo '<p><a href="?appointment='.$adsID.'" class="button-link">طلب معاينة عقار</a></p>';
            ?>
            <p><b>المدينة:</b> <?php echo $row['cityTitle'];?></p>
            <p><b>القسم:</b> <?php echo $row['catTile'];?></p>
            <h3>وصف الإعلان:</h3>
            <p><?php echo nl2br($row['description']);?></p>
            <h3>المنافع:</h3>
            <p>
        	
<ul>
<?php
$command 	= "SELECT AD.*, DK.title FROM `adsdetails` as AD 
JOIN detailskeys as DK ON DK.keyID=AD.keyID
WHERE AD.adID='".$row['adID']."' ";
$result		=	$connect->query($command);
while ( $key = mysqli_fetch_assoc($result)){
    echo '<li>'.$key['title'].'</li>';
} 
?>
</ul>
        </p>
        <p><b>تاريخ الإغلاق:</b> <?php echo $row['closeDate'];?></p>
        <p><b>تاريخ إضافة الإعلان:</b> <?php echo $row['insertDate'];?></p>

        <button onclick="showModal()">المعلن: <?php echo $row['name']; ?></button>
        </div>



<!-- Hidden modal -->
<div id="infoModal" style="display: none;">
<h2>بيانات المعلن</h2>
    <p>الإسم: <?php echo $row['name']; ?></p>
    <p>الجوال: <?php echo $row['mobile']; ?></p>
    <p>الإيميل: <?php echo $row['email']; ?></p>
    <p>العنوان: <?php echo $row['address']; ?></p>
    <button onclick="hideModal()">Close</button>
</div>


        <!-- Add more property cards as needed -->

    </section>
    <style>
.bid-card {
    position: relative; /* This makes the positioning of the .image-label relative to the .bid-card */
    border: 1px solid #ddd;
    padding: 15px;
    margin-bottom: 20px;
    background-color: #f8f9fa;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
    width: 90%;
    margin: 10px;
}

.bid-card button {
    background-color: #4CAF50; /* Green */
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    margin-top: 10px;
    margin-left: -100px;
}
.bid-card button:hover {
    background-color: #45a049;
}
.bid-labels {
    position: absolute;
    top: 10px;
    left: 10px; /* Adjust this to align the label as needed */
    background-color: rgba(255, 0, 0, 0.8); /* Semi-transparent red */
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 14px; /* Adjust font size as necessary */
}
</style>
<section class="bids-section">
    <div class="h2-container">
        <h2>قائمة العروض</h2>
    </div>
    
 <?php    


if(is_found_approed_offer($adsID)==FALSE)
$sqlOffers = "
SELECT b.*, c.name,  c.mobile FROM `buyeroffers`  as b
INNER JOIN clients as c on c.clientID=b.clientID
WHERE b.adID='$adsID';
";
else
$sqlOffers = "
SELECT b.*, c.name, c.mobile  FROM `buyeroffers`  as b
INNER JOIN clients as c on c.clientID=b.clientID
WHERE b.adID='$adsID' and b.status='approved'
";

$last_offer = FALSE;
$resultOffers		=	$connect->query($sqlOffers);

while ( $Offer = mysqli_fetch_assoc($resultOffers)){
    echo '
    <div class="bid-card">
        <div class="bid-labels">'.show_type_offer($Offer['status']).'</div>';
        
        if(checker_owner()==TRUE AND $_SESSION['userid']==$row['ownerID'])
           echo ' <h3>اسم العميل: '.$Offer['name'].' [<img src="images/mobile.png"> '.$Offer['mobile'].']</h3>';
        else
           echo ' <h3>اسم العميل: '.$Offer['name'].'</h3>';
        
        echo 
        '<p>مبلغ العرض: '.$Offer['offerValue'].'</p>
        <p>'.nl2br($Offer['comment']).'</p>';
        if($Offer['status']=='new' AND checker_owner()==TRUE AND $_SESSION['userid']==$row['ownerID'] AND ($row['status']=='new' OR $row['status']=='open' ) )
            echo '<button  onclick="location.href=\'?show='.$adsID.'&offer='.$Offer['offerID'].'\';"  >قبول العرض</button>';
    
    echo '</div>';

    
$last_offer = $Offer['offerValue'];
}
    ?>
    <!-- Additional bid cards can be added similarly -->
</section>


<?php 
if(

        checker_client()==TRUE

        
){
    
    ?>
    
    <style>

    </style>

 <form class="bid-form" action="" method="post">
    <h2>أضف عرضك</h2>
<?php
   
   if(isset($_POST['submitBid'])){
    $adID = (int)$_GET['show'];
    $clientID = (int)$_SESSION['userid'];
    
    $bidAmount = $_POST['bidAmount'];
    $bidMessage = $_POST['bidMessage'];
    
    $command 	= "
    insert into buyeroffers (`offerID`, `adID`, `clientID`, `comment`, `offerValue`, `closeDate`, `status`, `insertDate`)
    VALUES (NULL,'$adID','$clientID','$bidMessage' , '$bidAmount', NULL, 'new', CURRENT_TIMESTAMP)
    ";
            $result		=	$connect->query($command);
    if(isset($connect->insert_id) AND $connect->insert_id>0) {
        
        echo '<div class="message-box success-message" id="bid-success-message">تم إضافة عرضك بنجاح</div>';
        header("refresh:2; url=$actual_link");
    } else {
        echo  '<div class="message-box error-message" id="bid-error-message">حدث خطأ , تأكد من بيانات عرضك</div>';

    }
}


$type = $row['type'];
if($type=='bid')
{
    if($last_offer!=FALSE){        
        $more_for_input = ' min="'.$last_offer.'" ';
    }else{
         $more_for_input = ' min="50" ';
    }

}else{
    $more_for_input = ' ';
}

?>
    <label for="bidAmount">العرض</label>
    <input type="number" id="bidAmount" <?php echo  $more_for_input;?> name="bidAmount" required>

    <label for="bidMessage">تعليقك</label>
    <textarea id="bidMessage" name="bidMessage" required></textarea>

    <button type="submit" name="submitBid">إعتمد العرض</button> <!-- Changed to type "submit" -->

    
    
</form>

<?php  } ?>



<script type="text/javascript" src="js/script.js"></script>

<script>
    function showModal() {
    document.getElementById('infoModal').style.display = 'block';
}

function hideModal() {
    document.getElementById('infoModal').style.display = 'none';
}
</script>
