

    <form action ="" Method="POST">
        <h2>التسجيل كمسؤول عقار</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 
				AND is_data_found("facilities_owners","email",$_POST['email'])==FALSE
				AND is_data_found("facilities_owners","username",$_POST['username'])==FALSE
				AND is_data_found("facilities_owners","mobile",(int)$_POST['mobile'])==FALSE
		  ){
			
			$name		=	$_POST['name'];
			$email		=	$_POST['email'];
			$username	=	$_POST['username'];
			$password	=	md5($_POST['password']);
			$mobile		=	(int)$_POST['mobile'];
			$address	=	$_POST['address'];
			
			$command 	= " insert into facilities_owners (`ownerID`, `name`, `username`, `email`, `password`, `mobile`, `address`, `insertDate`)
			values (NULL, '$name', '$username', '$email', '$password' , '$mobile', '$address', current_timestamp)	";
			$insert		=	$connect->query($command);
			
			login_owner($username, $_POST['password']);
			
			echo ' <div class="message-show success-messages"  >تم التسجيل بنجاح وجاري تحويلك إلى صفحة الرئيسية</div>';
			header ("refresh:3; url=index.php");
			die();
		}elseif(isset($_POST['Go'])){
				$msg	=	"";
				if(is_data_found("facilities_owners","email",$_POST['email'])==TRUE)
					$msg .="عذرا البريد الإلكتروني موجود لدى عضو أخر";
				if( is_data_found("facilities_owners","username",$_POST['username'])==true)
					$msg .="<br>عذرا إسم المستخدم موجود لدى عضو أخر";
				if(is_data_found("facilities_owners","mobile",(int)$_POST['mobile'])==true)
					$msg .="<br>عذرا رقم الجوال موجود لدى عضو أخر";
			
			echo ' <div class="message-show error-message"  >'.$msg.'</div>';		

		}
        
        ?>
        <label >الإسم</label>
        <input type="text" name="name" <?php if(isset($_POST['name'])) echo  ' value="'.$_POST['name'].'" '; ?> required>
        <label>البريد الإلكتروني</label>
        <input type="email" name="email" <?php if(isset($_POST['email'])) echo  ' value="'.$_POST['email'].'" '; ?>required>
        <label >إسم المستخدم</label>
        <input type="text" name="username" <?php if(isset($_POST['username'])) echo  ' value="'.$_POST['username'].'" '; ?> required>
        <label >كلمة المرور</label>
        <input type="password" name="password" required>
        <label >رقم الجوال</label>
        <input type="text" name="mobile" <?php if(isset($_POST['mobile'])) echo  ' value="'.$_POST['mobile'].'" '; ?> required>
        <label >العنوان</label>
        <input type="text" name="address" <?php if(isset($_POST['address'])) echo  ' value="'.$_POST['address'].'" '; ?> required>
        
        <input type="submit" name="Go" value="سجل" >
       
        
    </form>
