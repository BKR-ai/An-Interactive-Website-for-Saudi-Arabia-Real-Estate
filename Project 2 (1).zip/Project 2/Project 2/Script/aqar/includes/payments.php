<div class="user-table-container">
			 
			  <h2>قائمة الدفعات</h2>
	<?php
    
    if(isset($_GET["approved"])){
        $brokerageID   =$_GET["approved"];
        $adID   = show_data_founded('brokerage_value','brokerageID',$brokerageID,'adID');
        $update  = $connect->query("update brokerage_value set paymentStatus='approved'  where brokerageID='$brokerageID' ");
        $update  = $connect->query("update ads set status='finished'  where adID='$adID' ");
        echo ' <div class="message-show success-messages"  >تم قبول الدفعة وتم إغلاق المزاد بشكل نهائي </div>';
        header ("refresh:3; url=?");
        die();
    }
     
    if(isset($_GET["rejected"])){
        $brokerageID   =$_GET["rejected"];
        $update  = $connect->query("update brokerage_value set paymentStatus='rejected'  where brokerageID='$brokerageID' ");
        echo ' <div class="message-show success-messages"  >تم رفض الدفعة وتم الطلب من البائع إعادة دفع المستحقات مرة أخرى</div>';
        header ("refresh:3; url=?");
        die();  
    }
    
    ?>
              


        <table>
            <thead> 
                <tr>  
                    <th>رقم الإعلان</th> 
                    <th>العنوان</th>
                    <th>البائع</th>
                    <th>الجوال</th>
                    <th>الإيميل</th>
                    <th>المبلغ المدفوع</th>
                    <th>الإيصال</th>
                    <th>حالة التأكيد</th>
                    <th>تاريخ الدفع</th>
                </tr>
            </thead>
            <tbody>  
		<?php

		$command 	= "
        SELECT bf.*, fo.name , fo.mobile, fo.email , a.title FROM `brokerage_value` as bf 
        INNER JOIN ads as a on a.adID=bf.adID
        INNER JOIN facilities_owners as fo on fo.ownerID=bf.ownerID;
        ";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  
                    <td><a href="ads.php?show='.$row['adID'].'">'.$row['adID'].'</a></td>
                    <td>'.$row['title'].'</td>
                    <td>'.$row['name'].'</td>
                    <td>'.$row['mobile'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['value'].'</td>
                    <td><a href="'.$folder_uploads.$row['reciteImage'].'" target="_blank"><img src="'.$folder_uploads.$row['reciteImage'].'" style="max-width:120px" ></a></td>
                    <td>'.brokerage_status($row['paymentStatus']);

                    if($row['paymentStatus']=='waiting')
                       echo '<br> <a href="?approved='.$row['brokerageID'].'" ><img src="images/approved.png"></a> ;
                       <a href="?rejected='.$row['brokerageID'].'" ><img src="images/rejected.png"></a>';
                    echo 
                    '</td>
                    <td>'.$row['insertDate'].'</td>
                                     
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
