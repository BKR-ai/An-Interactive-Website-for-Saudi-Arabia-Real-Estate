

    <form action ="" Method="POST">
        <h2>إضافة قسم عقاري</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 
				AND is_data_found("categories","title",$_POST['title'])==FALSE
			
		  ){
			
			$title		=	$_POST['title'];
			
			
			$command 	= " insert into categories (`catID`, `title` )
			values (NULL, '$title' )	";
			$insert		=	$connect->query($command);
			
			echo ' <div class="message-show success-messages"  >تمت الإضافة بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
			die();
		}elseif(isset($_POST['Go'])){
				$msg	=	"";
				if(is_data_found("categories","title",$_POST['title'])==TRUE)
					$msg .="عذرا المدينة موجودة مسبقا";
		
			
			echo ' <div class="message-show error-message"  >'.$msg.'</div>';		

		}
        
        ?>
        <label >مسمى القسم</label>
        <input type="text" name="title" <?php if(isset($_POST['title'])) echo  ' value="'.$_POST['title'].'" '; ?> required>
         
        <input type="submit" name="Go" value="أضف" >
       
        
    </form>
