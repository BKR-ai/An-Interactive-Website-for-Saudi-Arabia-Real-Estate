<!-- 
(`ownerID`, `name`, `username`, `email`, `password`, `mobile`, `address`, `insertDate`) 
-->



         <div class="user-table-container">
			 
			  <h2>قائمة ملاك العقارات</h2>
			  <a class="btn info" href="?addOwner">إضافة</a>
        <table>
            <thead> 
                <tr>  
                    <th>الاسم</th> 
                    <th>إسم المستخدم</th>
                    <th>البريد الإلكتروني</th>
                    <th>رقم الجوال</th>
                    <th>العنوان</th>
                    <th>تاريخ التسجيل</th>
                    <th>تحديث كلمة المرور</th>
                    <th>التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
			
		$command 	= " select * from facilities_owners order by ownerID DESC";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  
                    <td>'.$row['name'].'</td>
                    <td>'.$row['username'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['mobile'].'</td>
                    <td>'.$row['address'].'</td>
                    <td>'.$row['insertDate'].'</td>
                    <td><a href="?editPassword='.$row['ownerID'].'" ><img src="images/forgot-password.png" > </a></td>
                    <td>
						<a href="?editOwner='.$row['ownerID'].'" ><img src="images/edit.png" > </a>
						<a href="?deleteOwner='.$row['ownerID'].'" ><img src="images/delete.png" ></a>
					</td>                   
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
