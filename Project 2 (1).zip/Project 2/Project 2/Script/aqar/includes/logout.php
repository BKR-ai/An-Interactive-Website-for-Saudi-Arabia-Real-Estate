

    <form action ="" Method="POST">
        <h2>الخروج من النظام</h2>
       
        <?php
			
			session_destroy();
			echo ' <div class="message-show success-messages"  >تم تسجيل خروجك من النظام بنجاح, وجاري تحويلك إلى الرئيسية</div>';
			header ("refresh:3; url=index.php");
		
		
        ?>
      
    </form>
