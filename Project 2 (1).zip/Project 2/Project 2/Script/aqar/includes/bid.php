
	<div class="bid-form">
        <h2>Bid for Real Estate Details</h2>
        <label for="bidderName">Your Name:</label>
        <input type="text" id="bidderName" name="bidderName" required>
        <label for="bidderEmail">Your Email:</label>
        <input type="email" id="bidderEmail" name="bidderEmail" required>
        <label for="bidAmount">Bid Amount:</label>
        <input type="number" id="bidAmount" name="bidAmount" required>
        <label for="bidMessage">Message:</label>
        <textarea id="bidMessage" name="bidMessage" required></textarea>
        <button type="button" onclick="submitBidForm()">Submit Bid</button>
        <div class="message-box success-message" id="bid-success-message"></div>
        <div class="message-box error-message" id="bid-error-message"></div>
    </div>




    <form >
        <h2>Contact Property Owner</h2>
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea>
        <button type="button" onclick="submitForm()">Send Message</button>
        <div class="message-box success-message" id="success-message"></div>
        <div class="message-box error-message" id="error-message"></div>
    </form>
