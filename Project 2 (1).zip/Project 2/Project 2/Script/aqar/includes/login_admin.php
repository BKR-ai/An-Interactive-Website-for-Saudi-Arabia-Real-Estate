<form action ="" Method="POST">
        <h2>الدخول إلى الإدارة</h2>
       
        <?php
        
        if( isset($_POST['Go']) AND login_admin($_POST['username'],md5($_POST['password']))==TRUE ){
			

			
			echo ' <div class="message-show success-messages"  >تم التحقق من البيانات وجاري تسجيل دخولك إلى الإدارة</div>';
			header ("refresh:3; url=?");
			die();
		}elseif( isset($_POST['Go']) ){
						echo ' <div class="message-show error-message"  >الرجاء التحقق من بيانات دخولك</div>';

		}
        
        ?>

        <label >إسم المستخدم</label>
        <input type="text" name="username" required>
        <label >كلمة المرور</label>
        <input type="password" name="password" required>

        <input type="submit" name="Go" value="دخول" >
       
        
    </form>
