


         <div class="user-table-container" style="margin:15px 25%">
			 
			  <h2>قائمة المدن</h2>
			  <a class="btn info" href="?addCity">إضافة</a>
        <table >
            <thead> 
                <tr>  
                    <th>المدينة</th> 
                    <th width="100px">التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
			
		$command 	= " select * from cities order by cityID DESC";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  
                    <td>'.$row['title'].'</td>
                     <td>
						<a href="?editCity='.$row['cityID'].'" ><img src="images/edit.png" > </a>
						<a href="?deleteCity='.$row['cityID'].'" ><img src="images/delete.png" ></a>
					</td>                   
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
