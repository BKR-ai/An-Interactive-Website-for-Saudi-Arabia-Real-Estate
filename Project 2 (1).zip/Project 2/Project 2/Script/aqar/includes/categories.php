


         <div class="user-table-container" style="margin:15px 25%">
			 
			  <h2>قائمة الأقسام العقارية</h2>
			  <a class="btn info" href="?addCategory">إضافة</a>
        <table >
            <thead> 
                <tr>  
                    <th>مسمى القسم</th> 
                    <th width="100px">التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
			
		$command 	= " select * from categories  order by catID  DESC";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  
                    <td>'.$row['title'].'</td>
                     <td>
						<a href="?editCategory='.$row['catID'].'" ><img src="images/edit.png" > </a>
						<a href="?deleteCategory='.$row['catID'].'" ><img src="images/delete.png" ></a>
					</td>                   
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
