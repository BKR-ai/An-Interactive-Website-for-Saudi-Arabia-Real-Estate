

    <form action ="" Method="POST">
        <h2>تعديل كلمة المرور لمسؤول عقاري</h2>
       
        <?php
        
        $id =	(int)$_SESSION['userid'];

        
        if( 
			isset($_POST['Go']) 
        ){
			
			$password	=	md5($_POST['password']);
			$connect->query(" update  facilities_owners set password = '$password'  where ownerID ='$id'	");
			
			echo ' <div class="message-show success-messages"  >تمت عملية التحديث بنجاح وجاري تحويلك إلى الخروج من النظام</div>';
			header ("refresh:3; url=logout.php");
			die();
			

		}
        
        ?>
      
      <label >كلمة المرور الجديدة</label>
        <input type="password" name="password" required>
        
        <input type="submit" name="Go" value="حدث" >
       
        
    </form>
