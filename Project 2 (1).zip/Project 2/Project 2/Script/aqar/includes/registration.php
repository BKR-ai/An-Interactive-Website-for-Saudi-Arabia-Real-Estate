<style>

#myDIV {
  height: 300px;
  display: grid;
  gap: 10px;
  background-color: #2196F3;
  padding: 10px;
  grid-template-columns: repeat(2, 1fr); /* Ensures two columns each taking 50% width */
}

#myDIV div {
  background-color: rgba(255, 255, 255, 0.8);
  display: flex;
  justify-content: center; /* Centers content horizontally */
  align-items: center;     /* Centers content vertically */
  height: 100%;            /* Takes full height of grid cell */
  font-size: 30px;
}
</style>


    <form action ="" Method="POST">
        <h2>التسجيل</h2>
       
       
<div id="myDIV">
  <div class="item"  onclick="location.href='?owner';" >التسجيل كصاحب عقار</div>
  <div class="item"  onclick="location.href='?client';" >التسجيل كعميل</div>
</div>


    </form>
