
    <section>  <!--  الـsection  يستخدم في تقسيم الصفحة الواحدة إلى عدة أقسام -->
        <div class="property-card">   <!-- بداية تصميم قسم عرض بيانات المنئشة -->
                      <button onclick="window.location.href='facilities_owners.php';" >التحكم بملاك العقارات</button>
                      <button onclick="window.location.href='clients.php';" >التحكم بالعملاء</button>
                      <button>التحكم بالعقارات</button>
                      
                      <button  onclick="window.location.href='cities.php';" >التحكم بالمدن</button>
                      <button  onclick="window.location.href='categories.php';" >التحكم بالأقسام</button>
                      <button  onclick="window.location.href='keys.php';" >التحكم بخصائص العقارات</button>
                      <button  onclick="window.location.href='ads.php';" >التحكم بالإعلانات</button>
                      <button  onclick="window.location.href='payments.php';" >التحكم بالمدفوعات</button>
        </div>


    </section>

