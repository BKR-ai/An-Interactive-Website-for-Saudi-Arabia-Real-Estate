


         <div class="user-table-container" style="margin:15px 25%">
			 
			  <h2>قائمة خصائص العقارات</h2>
			  <a class="btn info" href="?addKey">إضافة</a>
        <table >
            <thead> 
                <tr>  
                    <th>مسمى الخاصية</th> 
                    <th width="100px">التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
			
		$command 	= " select * from detailskeys  order by keyID  DESC";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  
                    <td>'.$row['title'].'</td>
                     <td>
						<a href="?editKey='.$row['keyID'].'" ><img src="images/edit.png" > </a>
						<a href="?deleteKey='.$row['keyID'].'" ><img src="images/delete.png" ></a>
					</td>                   
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
