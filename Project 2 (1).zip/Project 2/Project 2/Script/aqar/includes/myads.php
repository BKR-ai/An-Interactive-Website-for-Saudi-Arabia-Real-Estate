
<div class="user-table-container">
			 
			  <h2>قائمة إعلاناتك</h2>
			  <a class="btn info" href="?add">إضافة</a>
        <table>
            <thead> 
                <tr>  
                    <th>رقم الإعلان</th> 
                    <th>القسم</th>
                    <th>المدينة</th>
                    <th>عنوان الإعلان</th>
                    <th>الوصف</th>
                    <th>الصور</th>
                    <th>نوع الإعلان</th>
                    <th>الحالة</th>
                    <th>تاريخ الإغلاق</th>
                    <th>تاريخ الإضافة</th>
                    <th>التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
		// adID 	ownerID 	catID 	citeyID 	title 	description 	type  insertDate
		// sell,bid 	 new,paid,close
	
		$command 	= "
select ads.*,categories.title as catTile, cities.title as cityTitle from ads 
INNER JOIN categories 
INNER JOIN cities
where ownerID='".$_SESSION['userid']."'
and cities.cityID=ads.cityID
AND categories.catID=ads.catID
order by adID DESC;
        ";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		// '.$row['images'].'
		$images  = json_decode($row['images'],JSON_UNESCAPED_UNICODE);
		$listImage = "<ul>";
		foreach ($images AS $img){
			$listImage .= "<li><a href='".$folder_uploads.$img."' target='_blank'>".$img."</a></li>";
		}
		$listImage .= "</ul>";
			echo '
                <tr>  
                    <td>
                        <a href="?show='.$row['adID'].'">'.$row['adID'].'</a><br>';
                        if(is_have_appointments($row['adID'])==TRUE){
                            echo "<a href='?appointments=".$row['adID']."'  class='button-link' >لديك طلب معاينة</a>";
                        }                
                echo '
                    </td>
                    <td>'.$row['catTile'].'</td>
                    <td>'.$row['cityTitle'].'</td>
                    <td>'.$row['title'].'</td>
                    <td>
                        <small>'.substr($row['description'], 0, 100).'
                    </td>
                    <td>'.$listImage.'</td>
                    <td>'.$ads_types[$row['type']].'</td>
                    <td>'.$ads_statuses[$row['status']].'</td>
                    <td>'.$row['closeDate'].'</td>
                    <td>'.$row['insertDate'].'</td>
                    <td>
						
						';
                        $arr = array('accept', 'paid','finished');
                        if(!in_array($row['status'],$arr))
                            echo '<a href="?edit='.$row['adID'].'" ><img src="images/edit.png" ></a><br>';
                       
                            if($row['status']=='new' OR $row['status']=='open')
                            echo '<a href="?close='.$row['adID'].'" ><img src="images/close.png" ></a><br>';
						elseif( $row['status']=='close')
                            echo '<a href="?open='.$row['adID'].'" ><img src="images/open.png" ></a>';
                        elseif( $row['status']=='accept' AND is_found_recite($row['adID'])==FALSE)
                            echo '<a href="?confirmPay='.$row['adID'].'" ><img src="images/pay.png" ></a>';
                        elseif(is_found_recite_waiting($row['adID'])==TRUE)
                            echo    'بإنتظار التأكيد';
                        elseif(is_found_recite_rejected($row['adID'])==true)
                                echo '<a href="?confirmPay='.$row['adID'].'" >إعادة الدفع</a>';

				echo '	
                        </td>                   
                </tr>';
                if(ads_have_appointments($row['adID'])==TRUE){
                echo '<tr>
                        <th colspan=2>مواعيد المعاينة لإعلان رقم '.$row['adID'].'</th>
                        <td colspan=9 style="text-align:right;">
                            <ul>';

                            $commandAppointment 	= "
                            SELECT p.appointmentID,p.status,p.appointmentDate, c.name, c.mobile,c.email, c.address FROM `appointments` as p 
                           INNER JOIN clients as c on c.clientID=p.clientID
                           WHERE p.adID='".$row['adID']."';
                                   ";
                                   $resultAppointment		=	$connect->query($commandAppointment);
                                   while ( $Appointment = mysqli_fetch_assoc($resultAppointment))
                                            echo '<li>الإسم: ['.$Appointment['name'].'], الجوال:['.$Appointment['mobile'].'], الموعد['.$Appointment['appointmentDate'].']</li>';
                            
                            echo '

                                </ul>
                        </td>
                </tr>';

                    }
          } ?>       
                
            </tbody>
        </table>
    </div>

