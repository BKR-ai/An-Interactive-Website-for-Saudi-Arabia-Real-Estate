<?php
$server		=	"localhost"; // server
$username	=	"root"; // username of database
$password  	=	""; // password for  username of database
$dataname	=	"aqar"; // dataname 

$connect =	new mysqli($server, $username, $password, $dataname);

$connect->set_charset("utf8");

$siteTitle		=	"سوق عقارات المملكة";
$admin_username	=	"admin";
$admin_password	=	md5("Ksa123123");

session_start();

$ads_types	=	array(
	"sell"=>"بيع مباشر"
	,"bid"=>"مزايده"
);

$ads_statuses	=	array(
//  new,paid,close
	"new"=>"متاح"
	,"open"=>"متاح"
	,"paid"=>"مدفوع"
	,"accept"=>"مقبول"
	,"close"=>"مغلق"
	,"finished"=>"منتهي"
);

$folder_uploads	=	"uploads/";

$site_percentage = "1";

?>
