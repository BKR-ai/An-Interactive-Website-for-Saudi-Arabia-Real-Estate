

    <form action ="" Method="POST">
        <h2>إغلاق الإعلان</h2>
       
        <?php
        
        $adID 		=	(int)$_GET['close'];

        $command 	= 	"
        UPDATE ads
        SET status = 'close'
        where adID = '$adID'
        ";
       
		$result		=	$connect->query($command);
		
			echo ' <div class="message-show success-messages"  >تمت عملية إغلاق الإعلان بنجاح وجاري تحويلك إلى صفحة إعلاناتك</div>';
			header ("refresh:3; url=?");
		
		
        ?>
      
    </form>
