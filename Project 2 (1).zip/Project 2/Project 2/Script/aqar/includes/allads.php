<div class="user-table-container">
			 
			  <h2>قائمة الإعلانات</h2>
        <table>
            <thead> 
                <tr>  
                    <th>رقم الإعلان</th> 
                    <th>القسم</th>
                    <th>المدينة</th>
                    <th>عنوان الإعلان</th>
                    <th>الوصف</th>
                    <th>الصور</th>
                    <th>نوع الإعلان</th>
                    <th>الحالة</th>
                    <th>تاريخ الإغلاق</th>
                    <th>تاريخ الإضافة</th>
                    <th>التحكم</th>
                </tr>
            </thead>
            <tbody>  
		<?php
		// adID 	ownerID 	catID 	citeyID 	title 	description 	type  insertDate
		// sell,bid 	 new,paid,close
	
		$command 	= "
select ads.*,categories.title as catTile, cities.title as cityTitle from ads 
INNER JOIN categories 
INNER JOIN cities
where cities.cityID=ads.cityID
AND categories.catID=ads.catID
order by adID DESC;
        ";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		// '.$row['images'].'
		$images  = json_decode($row['images'],JSON_UNESCAPED_UNICODE);
		$listImage = "<ul>";
		foreach ($images AS $img){
			$listImage .= "<li><a href='".$folder_uploads.$img."' target='_blank'>".$img."</a></li>";
		}
		$listImage .= "</ul>";
			echo '
                <tr>  
                    <td>
                        <a href="?show='.$row['adID'].'">'.$row['adID'].'</a>
                    </td>
                    <td>'.$row['catTile'].'</td>
                    <td>'.$row['cityTitle'].'</td>
                    <td>'.$row['title'].'</td>
                    <td><small>'.nl2br($row['description']).'</small></td>
                    <td>'.$listImage.'</td>
                    <td>'.$ads_types[$row['type']].'</td>
                    <td>'.$ads_statuses[$row['status']].'</td>
                    <td>'.$row['closeDate'].'</td>
                    <td>'.$row['insertDate'].'</td>
                    <td>
                         <a href="?remove='.$row['adID'].'" ><img src="images/delete.png" ></a>
                    </td>                   
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
