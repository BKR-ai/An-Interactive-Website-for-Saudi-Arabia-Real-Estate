
<?php
$adsID = $_GET['open'];
$command 	= " 
select ads.closeDate from ads 
INNER JOIN categories 
INNER JOIN cities
where ownerID='".$_SESSION['userid']."'
and cities.cityID=ads.cityID
AND categories.catID=ads.catID
and ads.adID='".$adsID."'

order by adID DESC
";
$result		=	$connect->query($command);
$ads        = mysqli_fetch_assoc($result);


?>
    <form action ="" Method="POST" enctype="multipart/form-data" >
        <h2>فتح إعلان</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 

		  ){
			
			$closeDate			=	date('Y-m-d', strtotime($_POST['closeDate']));
	

			$command 	= "
            update ads set status='open',closeDate ='$closeDate' 
            where adID= '$adsID'
			";
			$update		=	$connect->query($command);

			echo ' <div class="message-show success-messages"  >تمت فتح إعلانك بنجاح وجاري تحويلك إلى قائمة إعلاناتك</div>';
			header ("refresh:3; url=?");
			die();
			

		}
        
        ?>
       
		<label >تاريخ الإغلاق</label>
        <input type="date" name="closeDate" min="<?php echo date('Y-m-d');?>" <?php if(isset($_POST['closeDate'])) echo  ' value="'.$_POST['closeDate'].'" ';else echo ' value="'.$ads['closeDate'].'" '; ?> required>
        


        <input type="submit" name="Go" value="إفتح" >
       
        
    </form>
