<?php
$id = (int)$_GET['appointments'];


?>
<div class="user-table-container">
			 
			  <h2>قائمة المواعيد للعقار</h2>
			  <h3><?php echo show_data_founded('ads','adID',$id,'title');?></h3>
			  
        <table>
            <thead> 
                <tr>  
                    <th>العميل</th> 
                    <th>جواله</th> 
                    <th>إيميه</th> 
                    <th>عنوانه</th> 
                    <th>الموعد</th>
                    
                </tr>
            </thead>
            <tbody>  
		<?php
	
		$command 	= "

 SELECT p.appointmentID,p.status,p.appointmentDate, c.name, c.mobile,c.email, c.address FROM `appointments` as p 
INNER JOIN clients as c on c.clientID=p.clientID
WHERE p.adID='$id' and p.status='new';
        ";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){
		
			echo '
                <tr>  

                    <td>'.$row['name'].'</td>
                    <td>'.$row['mobile'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['address'].'</td>
                    <td>'.$row['appointmentDate'].'</td>
                                     
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>
<?php
$command 	= "update appointments set status='view' where adID='$id'";
$connect->query($command);