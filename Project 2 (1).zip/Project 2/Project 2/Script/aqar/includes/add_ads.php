

    <form action ="" Method="POST" enctype="multipart/form-data" >
        <h2>إضافة إعلان</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 

		  ){
			
			$title				=	$_POST['title'];
			$description		=	addslashes($_POST['description']);
			$catID				=	(int)$_POST['catID'];
			$cityID				=	(int)$_POST['cityID'];
			$type				=	$_POST['type'];
			$closeDate			=	date('Y-m-d', strtotime($_POST['closeDate']));
			$image_array		=	array();
			$ownerID			=	(int)$_SESSION['userid'];
			
// Count # of uploaded files in array
$total = count($_FILES['images']['name']);

// Loop through each file
for( $i=0 ; $i < $total ; $i++ ) {

  //Get the temp file path
  $tmpFilePath = $_FILES['images']['tmp_name'][$i];
  $EXTENSION 	= strtolower(pathinfo($_FILES['images']['name'][$i],PATHINFO_EXTENSION));
  $newImageName	=	rand(22,9999).time().".".$EXTENSION;
  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = $folder_uploads.$newImageName;

    //Upload the file into the temp dir
    if(move_uploaded_file($tmpFilePath, $newFilePath)) {

      array_push($image_array,$newImageName);

    }
  }
}

$imagesJson	=	json_encode($image_array,true);

			$command 	= "
			INSERT INTO `ads` (`adID`, `ownerID`, `catID`, `cityID`, `title`, `description`, `images`, `type`, `closeDate`, `status`, `insertDate`) 
			VALUES (NULL, '$ownerID', '$catID', '$cityID', '$title', '$description', '$imagesJson', '$type', '$closeDate', 'new', current_timestamp()) 
			";
			$insert		=	$connect->query($command);
			$adID   	 = $connect->insert_id;
			foreach ($_POST['keys'] AS $index=>$value){
				$keyID = (int)$value;
				if(!empty($keyID) and $keyID>0){
					$command = "INSERT INTO `adsdetails` (`adKeyID`, `adID`, `keyID`) 
					VALUES (NULL, '$adID', '$keyID' ) ";
					$insert = $connect->query($command);
				}
			}
			echo ' <div class="message-show success-messages"  >تمت الإضافة بنجاح وجاري تحويلك إلى قائمة إعلاناتك</div>';
			header ("refresh:3; url=?");
			die();
			

		}
        
        ?>
        <label >عنوان الإعلان</label>
        <input type="text" name="title" <?php if(isset($_POST['title'])) echo  ' value="'.$_POST['title'].'" '; ?> required>
        <label>الوصف</label>
        <textarea name="description" required><?php if(isset($_POST['description'])) $_POST['description']; ?></textarea>
        <label >القسم</label>
        <select name ="catID" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			// <option value=""></option>
			$command 	= " select * from categories  order by catID  DESC";
			$result		=	$connect->query($command);
			while ( $category = mysqli_fetch_assoc($result)){
				echo '<option value="'.$category['catID'].'">'.$category['title'].'</option>';
			}
			?>
        </select>
        <label >المدينة</label>
        <select name ="cityID" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			$command 	= " select * from cities  order by cityID  DESC";
			$result		=	$connect->query($command);
			while ( $city = mysqli_fetch_assoc($result)){
				echo '<option value="'.$city['cityID'].'">'.$city['title'].'</option>';
			}
			?>
        </select>
                
        <label >نوع الإعلان</label>
        <select name ="type" required>
			<option value="">الرجاء الإختيار من القائمة</option>
			<?php
			
			
			foreach($ads_types AS $type=>$title){
				echo '<option value="'.$type.'">'.$title.'</option>';
			}
			?>
        </select>
		
		<label >تاريخ الإغلاق</label>
        <input type="date" name="closeDate" min="<?php echo date('Y-m-d');?>" <?php if(isset($_POST['closeDate'])) echo  ' value="'.$_POST['closeDate'].'" '; ?> required>
        
        <label >الصور</label>
        <input type="file" name="images[]" accept="image/*" multiple required>
        
        <label>منتفعات العقار</label>

		
<?php
$command 	= " select * from detailskeys  order by keyID  DESC";
$result		=	$connect->query($command);
while ( $key = mysqli_fetch_assoc($result)){

echo '<label class="checkbox-container">
      '.$key['title'].'
      <input type="checkbox" name="keys[]" value="'.$key['keyID'].'">
      <span class="checkmark"></span>
    </label>';

} ?>    


        <input type="submit" name="Go" value="أضف" >
       
        
    </form>
