<!DOCTYPE html>
<html lang="ar" dir="rtl"> <!-- بداية تاق html --> 
<head>  <!-- بداية تاق الهيد وأغلب التاقات تكون للمتصفح --> 
    <meta charset="UTF-8">  <!-- تاق ترميز الصفحة لدعم اللغة العربية -->  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <!-- تاق تنسيق الصفحة مع مختلف الشاشات --> 
    <title><?php echo $siteTitle;?></title>  <!-- العنوان في المتصفح --> 
	<link href="css/style.css" rel="stylesheet">
</head>
<body>  <!-- تاق بداية محتويات الصفحة التي تظهر على الشاشة --> 

    <header>  <!-- تاق لرئسية الصفحة --> 
         <h1><?php echo $siteTitle;?></h1>
    </header>

   <nav> <!-- تاق النافبار وبه الشريط العلوي -->
       <?php 
        
        echo '<a href="index.php">الرئيسية</a>';
        if(checker_login()==false){
			echo '<a href="control.php">الإدارة</a>';
			echo '<a href="login.php">الدخول</a>';
			echo '<a href="registration.php">التسجيل</a>';
		}
		if(checker_admin()==true){
			echo '<a href="control.php">الإدارة</a>';
		}
        if(checker_login()==true AND checker_admin()==FALSE){
			echo '<a href="info.php">بياناتك الشخصية</a>';
        }
        if(checker_owner()==true){
			echo '<a href="ads.php">إعلاناتك</a>';
        }

        
        if(checker_client()==true){
			echo '<a href="ads.php?myoffers">عروضك</a>';
        }
        
        if(checker_login()==true){
			echo '<a href="logout.php">الخروج</a>';
        }
        ?>
    </nav>
