

    <form action ="" Method="POST">
        <h2>حذف خاصية عقار</h2>
       
        <?php
        
        $id 		=	(int)$_GET['deleteKey'];
        $command 	= 	" delete from detailskeys  where keyID ='$id'	limit 1 ";
		$result		=	$connect->query($command);
		
			echo ' <div class="message-show success-messages"  >تمت عملية الحذف بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
		
		
        ?>
      
    </form>
