

    <section>  <!--  الـsection  يستخدم في تقسيم الصفحة الواحدة إلى عدة أقسام -->
        <div class="property-card">   <!-- بداية تصميم قسم عرض بيانات المنئشة -->
            <div class="image-slider">   <!-- بادية الصور المتحركة لصور المنشئة -->
                <img src="images/image1.jpg" > <!-- تاق الصور  -->
                <img src="images/image2.jpg" >
                <img src="images/image3.jpg" >
                
                <div class="slider-nav"> <!-- بداية تاق الصور للتنقل بينها -->
                    <button onclick="prevImage()">Previous</button>  <!-- ايقونة السابق بالجافا سكريبت -->
                    <button onclick="nextImage()">Next</button>
                </div>
            </div>
            <h2>Property Title</h2> 
            <p>Location: City, State</p>
            <p>Price: $XXX,XXX</p>
            <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <button>Contact Owner</button>
        </div>

        <!-- Add more property cards as needed -->

    </section>
