

    <form action ="" Method="POST">
        <h2>تعديل بيانات مدينة</h2>
       
        <?php
        
        $id =	(int)$_GET['editCity'];
        $command 	= " select * from cities  where cityID ='$id'	limit 1 ";
		$result		=	$connect->query($command);
		$row 		= mysqli_fetch_assoc($result);
        
        if( 
			isset($_POST['Go']) 
				AND is_data_found_except("cities","title",$_POST['title'],'cityID',$id)==FALSE
			
        
        ){
			
			$title		=	$_POST['title'];
			
			$connect->query(" update  cities set title = '$title'  where cityID ='$id'	");
			
			echo ' <div class="message-show success-messages"  >تمت عملية التحديث بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
			die();
		}elseif(isset($_POST['Go'])){
				$msg	=	"";
				if(is_data_found_except("cities","title",$_POST['title'],'cityID',$id)==TRUE)
					$msg .="عذرا المدينة موجودة مسبقا";
				
			
			echo ' <div class="message-show error-message"  >'.$msg.'</div>';		

		}
        
        ?>
        <label >المدينة</label>
        <input type="text" name="title" value="<?php echo $row['title'];?>" required>
       
        <input type="submit" name="Go" value="حدث" >
       
        
    </form>
