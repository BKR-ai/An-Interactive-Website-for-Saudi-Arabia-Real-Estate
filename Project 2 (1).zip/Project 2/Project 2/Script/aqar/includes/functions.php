<?php


function login_admin($username, $password){
	global $admin_username,$admin_password;

	if($username==$admin_username AND $password==$admin_password)
	{
		$_SESSION['admin']		=	"ok";
		$_SESSION['user_type']	=	"admin";
		$_SESSION['user_name']	=	$username;
		return TRUE;
	}else
	{
		return FALSE;
	}
	
	
}


function login_owner($username, $password){
	 global $connect;
	$password	=	md5($password);
	$command 	= " select * from facilities_owners where username='$username' AND password!='$password' limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1){
		$row 	=	mysqli_fetch_assoc($result);
		$_SESSION['user_type']	=	"owner";
		$_SESSION['user_name']	=	$username;
		$_SESSION['userid']		=	$row['ownerID'];
		return TRUE;	
	
	}else
	{
		return FALSE;
	}
	
	
}

function login_client($username, $password){
	 global $connect;
	$password	=	md5($password);
	$command 	= " select * from clients where username='$username' AND password!='$password' limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1){
		$row 	=	mysqli_fetch_assoc($result);
		$_SESSION['user_type']	=	"client";
		$_SESSION['user_name']	=	$username;
		$_SESSION['userid']		=	$row['clientID'];
		return TRUE;	
	
	}else
	{
		return FALSE;
	}
	
	
}


function checker_admin(){
	if(isset($_SESSION['user_type']) AND $_SESSION['user_type']=='admin')
		return TRUE;
	else
		return FALSE;
}


function checker_owner(){
	if(isset($_SESSION['user_type']) AND $_SESSION['user_type']=='owner')
		return TRUE;
	else
		return FALSE;
}

function checker_client(){
	if(isset($_SESSION['user_type']) AND $_SESSION['user_type']=='client')
		return TRUE;
	else
		return FALSE;
}

function checker_login(){
	if(isset($_SESSION['user_type']))
		return TRUE;
	else
		return FALSE;
}


function is_have_appointments($adID){
	global $connect;

	$command 	= "SELECT *  FROM `appointments` WHERE `adID` ='$adID' AND `status` = 'new' limit 1 ";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}


function ads_have_appointments($adID){
	global $connect;

	$command 	= "SELECT *  FROM `appointments` WHERE `adID` ='$adID'  limit 1 ";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}
function is_data_found($table,$feild,$value){
	global $connect;

	$command 	= " select * from $table where $feild='$value'  limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}

function is_data_found_except($table,$feild,$value,$field2, $value2){
	global $connect;

	$command 	= " select * from $table where $feild='$value' AND $field2!='$value2' limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}

function show_type_ads($type){
	$types = array('sell'=>"بيع مباشر", 'bid'=>'مزاد');

	return $types[$type];
}

function brokerage_status($type){
	$types = array('waiting'=>"بإنتظار التأكيد", 'approved'=>'مؤكدة' ,'rejected'=>"مرفوضة");

	return $types[$type];
}

function show_type_offer($type){
	$types = array('new'=>"جديد", 'approved'=>'مقبول' ,'accept'=>"مقبول");

	return $types[$type];
}



function show_data_founded($table,$feild,$value,$target){
	global $connect;

	$command 	= " select $target from $table where $feild='$value'  limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1){
		$row = mysqli_fetch_assoc($result);
		return $row[$target];
	}else{
		return FALSE;
	}
	
}


function is_found_approed_offer($adID){
	global $connect;

	$command 	= " select * from buyeroffers where adID='$adID' and status='approved' limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}
function is_found_recite($adID){
	global $connect;

	$command 	= 	" select * from brokerage_value where adID='$adID' limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}

function is_found_recite_waiting($adID){
	global $connect;

	$command 	= 	" select * from brokerage_value where adID='$adID' and paymentStatus='waiting'  order by brokerageID DESC limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}

function is_found_recite_confirm($adID){
	global $connect;

	$command 	= 	" select * from brokerage_value where adID='$adID' and paymentStatus='confirm' order by brokerageID DESC  limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}

function is_found_recite_rejected($adID){
	global $connect;

	$command 	= 	" select * from brokerage_value where adID='$adID' and paymentStatus='rejected' order by brokerageID DESC limit 1";
	$result		=	$connect->query($command);
	$count_rows	=	$result->num_rows;
	if(isset($count_rows) AND $count_rows==1)
		return TRUE;
	else
		return FALSE;
	
}


function max_offer($adID){
	global $connect;

	$command 	= 	"SELECT max(offerValue) as maxMoney FROM `buyeroffers` WHERE adID='$adID';";
	$result		=	$connect->query($command);
	$row 		=	mysqli_fetch_assoc($result);
	return $row["maxMoney"];
	
}


?>
