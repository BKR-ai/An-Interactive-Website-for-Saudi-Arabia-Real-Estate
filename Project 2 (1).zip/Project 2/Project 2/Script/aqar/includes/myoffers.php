
<div class="user-table-container">
			 
			  <h2>قائمة عروضك</h2>
			  <a class="btn info" href="?add">إضافة</a>
        <table>
            <thead> 
                <tr>  
                    <th>رقم الإعلان</th> 
                    
                    <th>عنوان الإعلان</th>
                    
                    <th>الحالة</th>
                    <th>تاريخ الإضافة</th>
                </tr>
            </thead>
            <tbody>  
		<?php

		$command 	= "

SELECT buyeroffers.adID, buyeroffers.offerValue, buyeroffers.status
,buyeroffers.insertDate
,ads.title
,clients.name
FROM `buyeroffers` 
INNER JOIN ads on ads.adID=buyeroffers.adID
INNER JOIN clients on clients.clientID=buyeroffers.clientID
WHERE buyeroffers.clientID='".$_SESSION['userid']."';


        ";
		$result		=	$connect->query($command);
		while ( $row = mysqli_fetch_assoc($result)){

			echo '
                <tr>  
                    <td>
                        <a href="?show='.$row['adID'].'">'.$row['adID'].'</a><br>
                    </td>
                    <td>'.$row['title'].'</td>
                    <td>'.show_type_offer($row['status']).'</td>
                    <td>'.$row['insertDate'].'</td>
                                     
                </tr>';
          } ?>       
                
            </tbody>
        </table>
    </div>

