

    <form action ="" Method="POST">
        <h2>تعديل كلمة المرور لمسؤول عقار</h2>
       
        <?php
        
        $id =	(int)$_GET['editPassword'];

        
        if( 
			isset($_POST['Go']) 
        ){
			
			$password	=	md5($_POST['password']);
			$connect->query(" update  facilities_owners set password = '$password'  where ownerID ='$id'	");
			
			echo ' <div class="message-show success-messages"  >تمت عملية التحديث بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
			die();
			

		}
        
        ?>
      
      <label >كلمة المرور الجديدة</label>
        <input type="password" name="password" required>
        
        <input type="submit" name="Go" value="حدث" >
       
        
    </form>
