

    <form action ="" Method="POST">
        <h2>تعديل قسم</h2>
       
        <?php
        
        $id =	(int)$_GET['editCategory'];
        $command 	= " select * from categories  where catID ='$id'	limit 1 ";
		$result		=	$connect->query($command);
		$row 		= mysqli_fetch_assoc($result);
        
        if( 
			isset($_POST['Go']) 
				AND is_data_found_except("categories","title",$_POST['title'],'catID',$id)==FALSE
			
        
        ){
			
			$title		=	$_POST['title'];
			
			$connect->query(" update  categories set title = '$title'  where catID ='$id'	");
			
			echo ' <div class="message-show success-messages"  >تمت عملية التحديث بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
			die();
		}elseif(isset($_POST['Go'])){
				$msg	=	"";
				if(is_data_found_except("categories","title",$_POST['title'],'catID',$id)==TRUE)
					$msg .="عذرا الخاصية موجودة مسبقا";				
			
			echo ' <div class="message-show error-message"  >'.$msg.'</div>';		

		}
        
        ?>
        <label >مسمى القسم</label>
        <input type="text" name="title" value="<?php echo $row['title'];?>" required>
       
        <input type="submit" name="Go" value="حدث" >
       
        
    </form>
