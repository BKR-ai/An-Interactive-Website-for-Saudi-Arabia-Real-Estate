<?php

$command  ="select ads.*,categories.title as catTile, cities.title as cityTitle,
JSON_EXTRACT(ads.images, CONCAT('$[', FLOOR(RAND() * JSON_LENGTH(ads.images)), ']')) AS randomImage
from ads 
INNER JOIN categories 
INNER JOIN cities
where 
cities.cityID=ads.cityID
AND categories.catID=ads.catID
AND ads.closeDate>=now()
AND ads.status in ('open','new')
order by ads.adID DESC;"
?>

<section>
	  <?php 
      $result	=	$connect->query($command);
      while($row = mysqli_fetch_assoc($result)){
        $image = $row['randomImage'];
        $cleanedImage = str_replace('"', '', $image);

      ?>
      <div class="simple-property-card" onclick="window.location.href='ads.php?show=<?php echo $row['adID'];?>';" >
          <div class="image-label"><?php echo $ads_types[$row['type']];?></div> <!-- You can change this text based on the property status -->
          <img src="<?php echo $folder_uploads.$cleanedImage;?>" >
          <h2><?php echo $row['title'];?></h2>
          <p class="offer-label">آعلى عرض: <?php echo max_offer($row['adID'])?></p>
      </div>
     <?php  } ?>
      
  </section>
  