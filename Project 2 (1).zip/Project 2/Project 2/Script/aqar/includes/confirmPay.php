<?php

$adID       =   (int)$_GET['confirmPay'];
$command    =  " 
SELECT bf.offerID, bf.clientID , bf.adID,  bf.offerValue, ad.ownerID FROM `buyeroffers` as bf 
INNER JOIN ads as ad on ad.adID=bf.adID
WHERE  bf.status='approved'
AND 
bf.adID='$adID'";
$result		=	$connect->query($command);
$row        =   mysqli_fetch_assoc($result);


// (1000*(1/100))
$parcintage_ads  = $row['offerValue']*($site_percentage/100);

?>

    <form action ="" Method="POST" enctype="multipart/form-data" >
        <h2>تأكيد البيع ودفع نسبة الموقع</h2>
       
        <?php
        
        if( 	
				isset($_POST['Go']) 

		  ){
			
			$ownerID				=	$row['ownerID'];
			$offerID				=	$row['offerID'];
			$value				    =	$parcintage_ads;
			$rateValue				=	$site_percentage;

  //Get the temp file path
  $tmpFilePath = $_FILES['reciteImage']['tmp_name'];
  $EXTENSION 	= strtolower(pathinfo($_FILES['reciteImage']['name'],PATHINFO_EXTENSION));
  $newImageName	=	rand(22,9999).time().".".$EXTENSION;
  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = $folder_uploads.$newImageName;

    //Upload the file into the temp dir
    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
      $command 	= "INSERT INTO `brokerage_value` (`brokerageID`, `adID`, `ownerID`, `offerID`, `value`, `rateValue`, `paymentStatus`, `reciteImage`, `insertDate`) VALUES (NULL, '$adID', '$ownerID', '$offerID', '$value', '$rateValue', 'waiting', '$newImageName', current_timestamp()) ";
			$insert		=	$connect->query($command);
            echo ' <div class="message-show success-messages"  >تم رفع سند الدفع إلى إدارة الموقع, سيتم التحقق من دفعتك المالية وتأكيدها</div>';
			header ("refresh:5; url=?");
			die();
    }
  }
}

        
        ?>
        <label >سعر البيع</label>
        <input type="text" disabled <?php  echo ' value="'.$row['offerValue'].'" '; ?> >
        <label>المبلغ المستحق للموقع</label>
        <input type="text" disabled <?php  echo ' value="'.$parcintage_ads.'" '; ?> >
        <div class="message-show success-messages"  >يجب عليك دفع مبلغ <?php echo $parcintage_ads;?> وذلك مقابل خدمة إعلانك لدينا ولكي يتم إقفال الإعلان
        <br>
        نرجوا من سعادتكم إرفاق صورة إيصال التحويل لدى حسابنا البنكي:
        <br>
        بنك الرياض, أيبان  SA 11 3333 55566  7777
        </div>
        <label >صورة إيصال التحويل</label>
        <input type="file" name="reciteImage" accept="image/*"  required>
        


        <input type="submit" name="Go" value="أكد عملية الدفع" >
       
        
    </form>
