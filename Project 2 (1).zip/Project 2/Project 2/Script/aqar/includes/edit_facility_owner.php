

    <form action ="" Method="POST">
        <h2>تعديل بيانات مسؤول عقار</h2>
       
        <?php
        
        $id =	(int)$_GET['editOwner'];
        $command 	= " select * from facilities_owners  where ownerID ='$id'	limit 1 ";
		$result		=	$connect->query($command);
		$row 		= mysqli_fetch_assoc($result);
        
        if( 
			isset($_POST['Go']) 
				AND is_data_found_except("facilities_owners","email",$_POST['email'],'ownerID',$id)==FALSE
				AND is_data_found_except("facilities_owners","username",$_POST['username'],'ownerID',$id)==FALSE
				AND is_data_found_except("facilities_owners","mobile",(int)$_POST['mobile'],'ownerID',$id)==FALSE 
        
        ){
			
			$name		=	$_POST['name'];
			$email		=	$_POST['email'];
			$username	=	$_POST['username'];
			$mobile		=	(int)$_POST['mobile'];
			$address	=	$_POST['address'];
			
			$connect->query(" update  facilities_owners set name = '$name' , email='$email', username='$username', mobile='$mobile',  address='$address' where ownerID ='$id'	");
			
			echo ' <div class="message-show success-messages"  >تمت عملية التحديث بنجاح وجاري تحويلك إلى القائمة</div>';
			header ("refresh:3; url=?");
			die();
		}elseif(isset($_POST['Go'])){
				$msg	=	"";
				if(is_data_found_except("facilities_owners","email",$_POST['email'],'ownerID',$id)==TRUE)
					$msg .="عذرا البريد الإلكتروني موجود لدى عضو أخر";
				if( is_data_found_except("facilities_owners","username",$_POST['username'],'ownerID',$id)==true)
					$msg .="<br>عذرا إسم المستخدم موجود لدى عضو أخر";
				if(is_data_found_except("facilities_owners","mobile",(int)$_POST['mobile'],'ownerID',$id)==true)
					$msg .="<br>عذرا رقم الجوال موجود لدى عضو أخر";
			
			echo ' <div class="message-show error-message"  >'.$msg.'</div>';		

		}
        
        ?>
        <label >الإسم</label>
        <input type="text" name="name" value="<?php echo $row['name'];?>" required>
        <label>البريد الإلكتروني</label>
        <input type="email" name="email"  value="<?php echo $row['email'];?>" required>
        <label >إسم المستخدم</label>
        <input type="text" name="username"  value="<?php echo $row['username'];?>" required>
        <label >رقم الجوال</label>
        <input type="text" name="mobile"  value="<?php echo $row['mobile'];?>" required>
        <label >العنوان</label>
        <input type="text" name="address"  value="<?php echo $row['address'];?>" required>
        
        <input type="submit" name="Go" value="حدث" >
       
        
    </form>
