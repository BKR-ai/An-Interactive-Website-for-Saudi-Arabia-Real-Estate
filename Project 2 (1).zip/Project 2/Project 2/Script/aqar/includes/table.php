
         <div class="user-table-container">
        <table>
            <thead>  <!-- رئشية الجدول -->
                <tr>  <!-- سطر بالجدول -->
                    <th>الاسم</th>  <!-- th تستخدم في رئسية الجدول  -->
                    <th>الهاتف</th>
                    <th>البريد الإلكتروني</th>
                    <th>المدينة</th>
                </tr>
            </thead>
            <tbody>  <!-- محتوى الجدول -->
                <tr>  <!-- بداية سطر -->
                    <td>جون دو</td>
                    <td>123-456-7890</td>
                    <td>john@example.com</td>
                    <td>المدينة A</td>
                </tr>
                <!-- Add more rows as needed -->
            </tbody>
        </table>
    </div>
