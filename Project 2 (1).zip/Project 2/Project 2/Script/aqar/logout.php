<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


include_once	"includes/logout.php";

include_once	"includes/footer.php";

?>
