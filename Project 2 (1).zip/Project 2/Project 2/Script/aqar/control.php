<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	

		include_once	"includes/control.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
