<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	if(isset($_GET['addClient']))	
		include_once	"includes/add_client.php";
	elseif(isset($_GET['editClient']))	
		include_once	"includes/edit_client.php";
	elseif(isset($_GET['editPassword']))	
		include_once	"includes/password_client.php";
	elseif(isset($_GET['deleteClient']))	
		include_once	"includes/delete_client.php";
	else
		include_once	"includes/clients.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
