<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	if(isset($_GET['addCategory']))	
		include_once	"includes/add_category.php";
	elseif(isset($_GET['editCategory']))	
		include_once	"includes/edit_category.php";
	elseif(isset($_GET['deleteCategory']))	
		include_once	"includes/delete_category.php";
	else
		include_once	"includes/categories.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
