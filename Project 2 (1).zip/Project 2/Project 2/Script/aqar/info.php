<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";



	if(isset($_GET['data']) AND checker_owner()==true)	
		include_once	"includes/data_owner.php";
	elseif(isset($_GET['data']) AND checker_client()==true )	
		include_once	"includes/data_client.php";
	elseif(isset($_GET['password']) AND checker_client()==true )	
		include_once	"includes/password_client_new.php";
	elseif(isset($_GET['password']) AND checker_owner()==true )	
		include_once	"includes/password_owner.php";
	else
		include_once	"includes/info.php";

include_once	"includes/footer.php";

?>
