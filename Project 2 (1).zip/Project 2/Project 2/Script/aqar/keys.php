<?php

include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	if(isset($_GET['addKey']))	
		include_once	"includes/add_key.php";
	elseif(isset($_GET['editKey']))	
		include_once	"includes/edit_key.php";
	elseif(isset($_GET['deleteKey']))	
		include_once	"includes/delete_key.php";
	else
		include_once	"includes/keys.php";
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

?>
