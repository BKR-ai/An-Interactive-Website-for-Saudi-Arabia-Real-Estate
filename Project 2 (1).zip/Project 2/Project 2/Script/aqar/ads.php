<?php
ob_start();
include_once	"includes/connect.php";
include_once	"includes/functions.php";
include_once	"includes/header.php";


if(checker_admin()==TRUE){	
	
	if(isset($_GET['remove']))
		include_once	"includes/remove_ads.php";
	else
		include_once	"includes/allads.php";
}elseif(checker_owner()==TRUE){	

	if(isset($_GET['add']))
		include_once	"includes/add_ads.php";
	elseif(isset($_GET['edit']))
		include_once	"includes/edit_ads.php";	
	elseif(isset($_GET['delete_image']))
		include_once	"includes/delete_image.php";	
	elseif(isset($_GET['close']))
		include_once	"includes/close_ads.php";	
	elseif(isset($_GET['open']))
		include_once	"includes/open_ads.php";	
	elseif(isset($_GET['show']))
		include_once	"includes/show_ads.php";	
	elseif(isset($_GET['appointments']))
		include_once	"includes/ads_appointments.php";
	elseif(isset($_GET['confirmPay']))
		include_once	"includes/confirmPay.php";
	else
		include_once	"includes/myads.php";

}elseif(checker_client()==TRUE ){	
		if(isset($_GET["show"]))
		 	include_once	"includes/show_ads.php";
		elseif(isset($_GET["appointment"]))
		 	include_once	"includes/new_appointment.php";		
		elseif(isset($_GET["myoffers"]))
		 	include_once	"includes/myoffers.php";
}elseif(isset($_GET['show'])){
	include_once	"includes/show_ads.php";	
}else{
		include_once	"includes/login_admin.php";

}
include_once	"includes/footer.php";

ob_end_flush();
?>
