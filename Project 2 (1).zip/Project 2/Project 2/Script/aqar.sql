-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 11:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aqar`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `adID` int(11) NOT NULL,
  `ownerID` int(11) NOT NULL,
  `catID` int(11) NOT NULL,
  `cityID` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`images`)),
  `type` varchar(100) NOT NULL COMMENT 'sell,bid',
  `closeDate` date NOT NULL,
  `status` varchar(100) NOT NULL COMMENT 'new,paid,close, accept',
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`adID`, `ownerID`, `catID`, `cityID`, `title`, `description`, `images`, `type`, `closeDate`, `status`, `insertDate`) VALUES
(7, 5, 2, 1, 'شقة للبيع حي اليرموك', '5 غرف وصالة و5 دورات مياه ', '[\"10231715288792.jpeg\",\"10441715288792.jpeg\",\"55751715288792.jpeg\",\"29741715288792.jpeg\",\"26791715288792.jpeg\"]', 'sell', '2024-05-15', 'new', '2024-05-09 21:06:32'),
(8, 5, 1, 1, 'عمارة للبيع حي الدخل', 'دورين وملحق 5 شقق كل شقة 4 غرف وصالة', '[\"12411715288951.jpeg\"]', 'sell', '2024-05-15', 'new', '2024-05-09 21:09:11'),
(9, 5, 1, 1, 'فيلا للبيع حي الريان', 'فيلا مكونه من دورين وملحق', '[\"54611715289027.jpeg\",\"71781715289027.jpeg\",\"97471715289027.jpeg\",\"6511715289027.jpeg\",\"37991715289027.jpeg\"]', 'bid', '2024-05-15', 'new', '2024-05-09 21:10:27'),
(10, 5, 1, 1, 'فيلل روف حي المصيف', 'فلل روف في حي المصيف مدخل مستقل خزانات مستقله وعدادات مستقلة مكونه من 7 غرف و صالة ومطبخ ومستودع وسطح خااص', '[\"76351715289140.jpeg\",\"69451715289140.jpeg\",\"26631715289140.jpeg\"]', 'bid', '2024-05-15', 'new', '2024-05-09 21:12:20'),
(11, 5, 2, 1, 'شقة للبيع حي الصفا', '4 غرف وصالة و3 دورات مياه ', '[\"99821715289205.jpeg\",\"44061715289205.jpeg\",\"8801715289205.jpeg\"]', 'sell', '2024-05-15', 'new', '2024-05-09 21:13:25'),
(12, 5, 2, 1, 'شقة للبيع حي الاخضر', '5 غرف وصالة و5 دورات مياه مع مصعد جديد و سطح خاص', '[\"73131715289287.jpeg\"]', 'sell', '2024-05-15', 'new', '2024-05-09 21:14:47'),
(13, 5, 1, 1, 'عمارة تجارية للبيع ', '4 محلات و 40 شقة 74غرفة ', '[\"97121715289350.jpeg\"]', 'sell', '2024-05-15', 'accept', '2024-05-09 21:15:50'),
(14, 5, 1, 1, 'دور ارضي للبيع حي البوادي', 'مكون من 6 غرف و حوش ومدخلين خاصة', '[\"88891715289416.jpeg\"]', 'bid', '2024-05-22', 'new', '2024-05-09 21:16:56');

-- --------------------------------------------------------

--
-- Table structure for table `adsdetails`
--

CREATE TABLE `adsdetails` (
  `adKeyID` int(11) NOT NULL,
  `adID` int(11) NOT NULL,
  `keyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adsdetails`
--

INSERT INTO `adsdetails` (`adKeyID`, `adID`, `keyID`) VALUES
(26, 8, 5),
(27, 8, 4),
(28, 8, 3),
(29, 8, 2),
(30, 8, 1),
(31, 9, 5),
(32, 9, 4),
(33, 9, 3),
(34, 9, 1),
(35, 10, 4),
(36, 10, 3),
(37, 10, 2),
(38, 10, 1),
(39, 11, 5),
(40, 11, 4),
(41, 11, 3),
(42, 11, 2),
(43, 11, 1),
(44, 14, 5),
(45, 7, 5);

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointmentID` int(11) NOT NULL,
  `adID` int(11) NOT NULL,
  `ownerID` int(11) NOT NULL,
  `clientID` int(11) NOT NULL,
  `appointmentDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(100) NOT NULL,
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brokerage_value`
--

CREATE TABLE `brokerage_value` (
  `brokerageID` int(11) NOT NULL,
  `adID` int(11) NOT NULL,
  `ownerID` int(11) NOT NULL,
  `offerID` int(11) NOT NULL,
  `value` float NOT NULL,
  `rateValue` int(11) NOT NULL,
  `paymentStatus` varchar(100) NOT NULL COMMENT 'waiting,confirm',
  `reciteImage` varchar(100) NOT NULL,
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brokerage_value`
--

INSERT INTO `brokerage_value` (`brokerageID`, `adID`, `ownerID`, `offerID`, `value`, `rateValue`, `paymentStatus`, `reciteImage`, `insertDate`) VALUES
(2, 13, 5, 7, 5000, 1, 'waiting', '24991715290262.jpg', '2024-05-09 21:31:02');

-- --------------------------------------------------------

--
-- Table structure for table `buyeroffers`
--

CREATE TABLE `buyeroffers` (
  `offerID` int(11) NOT NULL,
  `adID` int(11) NOT NULL,
  `clientID` int(11) NOT NULL,
  `comment` text NOT NULL,
  `offerValue` float NOT NULL,
  `closeDate` date DEFAULT NULL,
  `status` varchar(100) NOT NULL COMMENT 'new,approved',
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buyeroffers`
--

INSERT INTO `buyeroffers` (`offerID`, `adID`, `clientID`, `comment`, `offerValue`, `closeDate`, `status`, `insertDate`) VALUES
(7, 13, 2, 'بعد المعاينة', 500000, NULL, 'approved', '2024-05-09 21:25:45'),
(8, 14, 2, 'ممتاز ', 1150000, NULL, 'new', '2024-05-09 21:26:38'),
(9, 12, 2, 'اتصل بي', 450000, NULL, 'new', '2024-05-09 21:27:01'),
(10, 8, 2, 'بعد حساب الدخل', 1500000, NULL, 'new', '2024-05-09 21:27:27'),
(11, 10, 2, 'اذا يوجد ضمانات', 880000, NULL, 'new', '2024-05-09 21:27:54');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catID` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catID`, `title`) VALUES
(4, 'ارض'),
(2, 'شقق'),
(1, 'فلل'),
(5, 'مخططات'),
(3, 'ملاحق');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `cityID` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`cityID`, `title`) VALUES
(3, 'الرياض'),
(1, 'تبوك'),
(2, 'جدة');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `clientID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`clientID`, `name`, `username`, `email`, `password`, `mobile`, `address`, `insertDate`) VALUES
(2, 'بكر عبدالعزيز', 'baker', 'bakerss@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 2147483647, 'تبوك, مروج الأمير', '2024-04-24 19:04:32');

-- --------------------------------------------------------

--
-- Table structure for table `detailskeys`
--

CREATE TABLE `detailskeys` (
  `keyID` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detailskeys`
--

INSERT INTO `detailskeys` (`keyID`, `title`) VALUES
(5, 'حوش'),
(2, 'سطح'),
(3, 'مخزن'),
(1, 'مطبخ'),
(4, 'مقلط');

-- --------------------------------------------------------

--
-- Table structure for table `facilities_owners`
--

CREATE TABLE `facilities_owners` (
  `ownerID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities_owners`
--

INSERT INTO `facilities_owners` (`ownerID`, `name`, `username`, `email`, `password`, `mobile`, `address`, `insertDate`) VALUES
(2, 'حمد سالم', 'akas', 'bb@ss.com', '0b3bb3224d1738740b64082ce44b86f9', 543345566, 'تبوك - مروج الأمير - شارع البازعي - بجوار صالون ليالي الشام', '2024-02-20 18:21:22'),
(4, 'سالم العنزي', 'sssssss', 'bssssssb@ss.com', '1863579b8604581b185735662a65d8ee', 543345533, 'تبوك - مروج الأمير - شارع البازعي - بجوار صالون ليالي الشام', '2024-02-20 18:59:12'),
(5, 'بكر عبدالعزيز', 'baker', 'baker@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 544444499, 'تبوك, مروج الأمير', '2024-04-24 18:56:11');

-- --------------------------------------------------------

--
-- Table structure for table `rates`
--

CREATE TABLE `rates` (
  `rateID` int(11) NOT NULL,
  `adID` int(11) NOT NULL,
  `clientID` int(11) NOT NULL,
  `comment` text NOT NULL,
  `rateValue` int(11) NOT NULL,
  `insertDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`adID`),
  ADD KEY `ownerID` (`ownerID`),
  ADD KEY `catID` (`catID`),
  ADD KEY `cityID` (`cityID`) USING BTREE;

--
-- Indexes for table `adsdetails`
--
ALTER TABLE `adsdetails`
  ADD PRIMARY KEY (`adKeyID`),
  ADD KEY `adID` (`adID`),
  ADD KEY `keyID` (`keyID`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointmentID`);

--
-- Indexes for table `brokerage_value`
--
ALTER TABLE `brokerage_value`
  ADD PRIMARY KEY (`brokerageID`),
  ADD KEY `adID` (`adID`),
  ADD KEY `ownerID` (`ownerID`);

--
-- Indexes for table `buyeroffers`
--
ALTER TABLE `buyeroffers`
  ADD PRIMARY KEY (`offerID`),
  ADD KEY `clientID` (`clientID`),
  ADD KEY `adID` (`adID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catID`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`cityID`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`clientID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `detailskeys`
--
ALTER TABLE `detailskeys`
  ADD PRIMARY KEY (`keyID`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `facilities_owners`
--
ALTER TABLE `facilities_owners`
  ADD PRIMARY KEY (`ownerID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`rateID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `adID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `adsdetails`
--
ALTER TABLE `adsdetails`
  MODIFY `adKeyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brokerage_value`
--
ALTER TABLE `brokerage_value`
  MODIFY `brokerageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `buyeroffers`
--
ALTER TABLE `buyeroffers`
  MODIFY `offerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `catID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `cityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `clientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `detailskeys`
--
ALTER TABLE `detailskeys`
  MODIFY `keyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `facilities_owners`
--
ALTER TABLE `facilities_owners`
  MODIFY `ownerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ads`
--
ALTER TABLE `ads`
  ADD CONSTRAINT `ads_ibfk_1` FOREIGN KEY (`ownerID`) REFERENCES `facilities_owners` (`ownerID`),
  ADD CONSTRAINT `ads_ibfk_2` FOREIGN KEY (`catID`) REFERENCES `categories` (`catID`),
  ADD CONSTRAINT `ads_ibfk_3` FOREIGN KEY (`cityID`) REFERENCES `cities` (`cityID`);

--
-- Constraints for table `adsdetails`
--
ALTER TABLE `adsdetails`
  ADD CONSTRAINT `adsdetails_ibfk_1` FOREIGN KEY (`adID`) REFERENCES `ads` (`adID`),
  ADD CONSTRAINT `adsdetails_ibfk_2` FOREIGN KEY (`keyID`) REFERENCES `detailskeys` (`keyID`);

--
-- Constraints for table `brokerage_value`
--
ALTER TABLE `brokerage_value`
  ADD CONSTRAINT `brokerage_value_ibfk_1` FOREIGN KEY (`adID`) REFERENCES `ads` (`adID`),
  ADD CONSTRAINT `brokerage_value_ibfk_2` FOREIGN KEY (`ownerID`) REFERENCES `facilities_owners` (`ownerID`);

--
-- Constraints for table `buyeroffers`
--
ALTER TABLE `buyeroffers`
  ADD CONSTRAINT `buyeroffers_ibfk_1` FOREIGN KEY (`clientID`) REFERENCES `clients` (`clientID`),
  ADD CONSTRAINT `buyeroffers_ibfk_2` FOREIGN KEY (`adID`) REFERENCES `ads` (`adID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
